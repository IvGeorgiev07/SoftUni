﻿namespace BorderControl
{
    public class StartUp
    {
        static void Main()
        {
            List<string> IdList = new List<string>();
            string firstInput = Console.ReadLine().TrimEnd();
            string[] input = firstInput.Split(" ", StringSplitOptions.RemoveEmptyEntries);            
            
            while (input[0]!="End")
            {
                IdList.Add(input[input.Length-1]);
                firstInput = Console.ReadLine().TrimEnd();
                input = firstInput.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            }

            string input2 = Console.ReadLine();

            for (int i = 0; i < IdList.Count; i++)
            {
                char[] arr = IdList[i].ToCharArray();
                string index = string.Empty;

                for (int j = 1; j <= input2.Length; j++)
                {
                    index += arr[arr.Length - j];
                }
                
                char[] indexCh = index.Reverse().ToArray();
                index = String.Join("", indexCh);

                if(index == input2)
                {
                    Console.WriteLine(IdList[i]);
                }

            }
        }
    }
}